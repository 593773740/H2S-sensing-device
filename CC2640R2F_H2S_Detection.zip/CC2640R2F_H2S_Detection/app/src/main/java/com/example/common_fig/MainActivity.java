package com.example.common_fig;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.preference.PreferenceManager;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.SimpleAdapter;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;



import com.example.common_fig.Bluetooth.Bluetooth_setting;
import com.example.common_fig.Bluetooth.BluetoothLeService;
import com.weiwangcn.betterspinner.library.BetterSpinner;

import java.io.File;
import java.io.FilenameFilter;
import java.io.IOException;
import java.lang.reflect.Method;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Timer;
import java.util.TimerTask;

import com.alibaba.sdk.android.oss.ClientConfiguration;
import com.alibaba.sdk.android.oss.ClientException;
import com.alibaba.sdk.android.oss.OSS;
import com.alibaba.sdk.android.oss.OSSClient;
import com.alibaba.sdk.android.oss.ServiceException;
import com.alibaba.sdk.android.oss.callback.OSSCompletedCallback;
import com.alibaba.sdk.android.oss.callback.OSSProgressCallback;
import com.alibaba.sdk.android.oss.common.OSSLog;
import com.alibaba.sdk.android.oss.common.auth.OSSCredentialProvider;
import com.alibaba.sdk.android.oss.common.auth.OSSPlainTextAKSKCredentialProvider;
import com.alibaba.sdk.android.oss.model.PutObjectRequest;
import com.alibaba.sdk.android.oss.model.PutObjectResult;

import lecho.lib.hellocharts.view.LineChartView;

public class MainActivity extends AppCompatActivity {

    private DataManager mData;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_default);
        //去除状态栏
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        //阻止休眠
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        Permission.verifyStoragePermissions(this);

        mDeviceAddress = getIntent().getStringExtra(Bluetooth_setting.DEVICE_ADDRESS);

        /*SharedPreferences preferences= PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
        mDeviceAddress=preferences.getString("DefaultBleAddress","");
        if(!mDeviceAddress.equals("")){
            BluetoothServiceinit();
        }*/


        initOSS();
        final int MY_PERMISSION_REQUEST_CODE = 10000;
        //要申请的权限（可以一次申请多个权限），存放到数组里
        final String[] permission = {
                Manifest.permission.READ_EXTERNAL_STORAGE,
                Manifest.permission.WRITE_EXTERNAL_STORAGE
        };
        ActivityCompat.requestPermissions(MainActivity.this, permission, MY_PERMISSION_REQUEST_CODE);


        mData=new DataManager(mHandler);  //mData是一个数据管理器

        //计时器更新时间
        Timer timer=new Timer();
        timer.schedule(new TimerTask() {
            @Override
            public void run() {
                //更新时间
                int h= Calendar.getInstance().get(Calendar.HOUR_OF_DAY);
                int m= Calendar.getInstance().get(Calendar.MINUTE);
                int t=h*60+m;
                if (t<0) t+=24*60;
                Message msg_time=new Message();
                msg_time.what=MSG_TIME;
                msg_time.arg1=(int)(t);
                mHandler.sendMessage(msg_time);
                pause=false;
            }
        },0,1000);

    }

    /*---------------------------------------------
    * 关于界面更新
    * --------------------------------------------*/
    private final int CLOSEPROGRESS = 0;
    private final int MSG_TIME = 2;

//    private List<String> data=new ArrayList<>();
    private boolean pause=false;
    private Handler mHandler=new Handler(new Handler.Callback() {
        @Override
        public boolean handleMessage(Message msg) {
            switch (msg.what){
                case CLOSEPROGRESS:
                    if (!mConnectState) {
                        //断开蓝牙的连接
                        closebluetooth();
                        Toast.makeText(getApplicationContext(), "连接失败!请重试", Toast.LENGTH_SHORT).show();
                    }else{
                    }
                    break;
                case DataManager.MSG_DATA:    //界面更新数据

                    if(pause) break;

                    TextView nitricoxide =findViewById(R.id.textView_nitricoxide );


                    Map<DataManager.ParameterType,Double> data=(Map<DataManager.ParameterType,Double>) msg.obj;
                    if(data==null) break;

                    nitricoxide .setText(String.format("%.1f",data.get(DataManager.ParameterType.NITRICOXIDE)));
                    nitricoxide .append(" "+mData.getUnit(DataManager.ParameterType.NITRICOXIDE));


                    nitricoxide .setText(String.format("%.1f",3.0));
                    nitricoxide .append(" "+mData.getUnit(DataManager.ParameterType.NITRICOXIDE));

                    pause=!pause;
                    break;
                case MSG_TIME:
                    TextView clock=findViewById(R.id.text_Time);
                    int sum,hour,min;
                    sum=msg.arg1;
                    if(sum>24*60) sum-=24*60;
                    hour=(int)Math.floor(sum/60);
                    min=sum-hour*60;
                    clock.setText(" "+hour+" : ");
                    if (min<10) clock.append("0"+min); else clock.append(""+min);
                    clock.append(" ");
                    break;
            }
            return false;
        }
    });

    /**
     * @param available 是否有数据即时更新
     */
    private boolean dataAvailable=false;
    private void updateDateAvailable(boolean available){
        dataAvailable=available;
        TextView title=findViewById(R.id.Test_title);
        if(available){
            title.setVisibility(View.VISIBLE);
            String name=mData.getFileName();
            if(name==null) name="";
            title.setText(name);
        }else{
            title.setText("");
        }
    }

    /*-----------------------------------------------
     * 菜单
     * ----------------------------------------------*/

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu,menu);
        return super.onCreateOptionsMenu(menu);
    }
    @Override
    public boolean onMenuOpened(int featureId, Menu menu) {  //设置显示menu的图标
        if (menu != null) {
            if (menu.getClass().getSimpleName().equalsIgnoreCase("MenuBuilder")) {
                try {
                    Method method = menu.getClass().getDeclaredMethod("setOptionalIconsVisible", Boolean.TYPE);
                    method.setAccessible(true);
                    method.invoke(menu, true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
        return super.onMenuOpened(featureId, menu);
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch(item.getItemId()){
            case android.R.id.home:
                finish();
                break;
            case R.id.new_test:
                final EditText editText = new EditText(MainActivity.this);
                AlertDialog.Builder inputDialog =
                        new AlertDialog.Builder(MainActivity.this);
                inputDialog.setTitle("Input Test Name（file name）").setView(editText);
                inputDialog.setNegativeButton("cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                    }
                });
                inputDialog.setPositiveButton("confirm",
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                String name=editText.getText().toString();
                                if(mData.setFileName(editText.getText().toString())){
                                    Toast.makeText(getApplicationContext(),"Create Sucess!",Toast.LENGTH_SHORT).show();
                                };
                                updateDateAvailable(true);
                            }
                        });
                inputDialog.show();
                break;
            case R.id.get_bluetooth_setting:
                if (mConnectState)
                    Toast.makeText(getApplicationContext(),"Bluetooth address:"+mDeviceAddress,Toast.LENGTH_LONG).show();
                else
                    Toast.makeText(getApplicationContext(),"Bluetooth disconnected",Toast.LENGTH_SHORT).show();
                break;
            case R.id.read_test:
                AlertDialog.Builder historyDialog =
                        new AlertDialog.Builder(MainActivity.this);
                File savefolder=new File(Environment.getExternalStorageDirectory().getAbsolutePath()+"/MultiParameterRecord");
                ArrayList<String> filelist=new ArrayList<>();
                if(savefolder.list()!=null)
                for(String name:savefolder.list()){
                    if(name.matches("[^.]+.csv")){
                        filelist.add(name);
                    }
                }
                ArrayAdapter<String> simpleAdapter=new ArrayAdapter<>(getApplicationContext(),
                    android.R.layout.simple_spinner_dropdown_item,filelist);
                BetterSpinner spinner=new BetterSpinner(getApplicationContext());
                spinner.setAdapter(simpleAdapter);
                historyDialog.setTitle("Choose a record to read:").setView(spinner);
                historyDialog.setNegativeButton("cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                    }
                });
                historyDialog.setPositiveButton("confirm",
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                mData.setFileName(spinner.getText().toString());
                                try {
                                    mData.readFileData();
                                    setContentView(R.layout.activity_default);
                                    updateDateAvailable(true);
                                }catch (IOException e){
                                    e.printStackTrace();
                                }
                            }
                        });
                historyDialog.show();
                break;
            case R.id.refresh_record:
                closebluetooth();
                mData.clearData();
                setContentView(R.layout.activity_default);
                break;
            case R.id.about_author:
                Toast.makeText(getApplicationContext(),"Made by student from SYSU",Toast.LENGTH_LONG).show();
                break;
        }
        return super.onOptionsItemSelected(item);
    }

    /*---------------------------------------------
    按键响应
    --------------------------------------------- */
    public void Onclick_button(View v) {
        if(!dataAvailable){
            Toast.makeText(getApplicationContext(),"No Data!",Toast.LENGTH_SHORT).show();
            return;
        }
        Button button = findViewById(v.getId());
        Intent intent = new Intent(MainActivity.this, DataFigureActivity.class);
        intent.putExtra("address",mDeviceAddress);
        intent.putExtra(Bluetooth_setting.CONNECT_STATE,mConnectState);
        intent.putExtra("title", button.getText().toString());
        startActivityForResult(intent,1);
    }

    private final int REQUEST_BLUETOOTHDEVICE = 0;

    public void Onclick_connect(View v) {
        if(!mConnectState){
            Intent intent = new Intent(MainActivity.this, Bluetooth_setting.class);
            startActivityForResult(intent, REQUEST_BLUETOOTHDEVICE);
        }else{
            closebluetooth();
        }

    }

    //-----------------------------------------------------------------
    //以下关于蓝牙活动
    //-----------------------------------------------------------------
    @Override
    protected void onResume() {
        super.onResume();
        final IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction(BluetoothLeService.ACTION_GATT_CONNECTED);
        intentFilter.addAction(BluetoothLeService.ACTION_GATT_DISCONNECTED);
        intentFilter.addAction(BluetoothLeService.ACTION_GATT_SERVICES_DISCOVERED);
        intentFilter.addAction(BluetoothLeService.ACTION_DATA_AVAILABLE);
        registerReceiver(mGattUpdateReceiver, intentFilter);

    }

    @Override
    protected void onPause() {
        unregisterReceiver(mGattUpdateReceiver);
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        closebluetooth();
        super.onDestroy();
    }

    private String mDeviceAddress;
    private boolean mConnectState;

    private BluetoothLeService mBluetoothLeService;//服务类的对象

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        //收到蓝牙地址的回复
        if (requestCode == REQUEST_BLUETOOTHDEVICE){
            if (resultCode == Bluetooth_setting.BLUETOOTHDEVICE_RESULT) {
                if (data == null) {
                    Log.e("onActivityResult:", "Null Intent");
                    return;
                }
                //确保读取到历史记录
                try{
                    mData.readFileData();
                }catch (IOException e){
                    e.printStackTrace();
                }
                mDeviceAddress = data.getStringExtra(Bluetooth_setting.DEVICE_ADDRESS);
                updateShowState();
                BluetoothServiceinit();

                SharedPreferences preferences=PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
                preferences.edit().putString("DefaultBleAddress",mDeviceAddress).apply();

            }
        }
        //从点击细节界面返回
        else{
            Message msg=new Message();
            msg.what=DataManager.MSG_DATA;
            msg.obj=mData.getMessageData();
            if(msg.obj==null)return;
            mHandler.sendMessage(msg);
        }
    }

    private void closebluetooth() {
        if (mBluetoothLeService != null) {
            mBluetoothLeService.close();
            unbindService(mServiceConnection);
            mBluetoothLeService = null;
        }
        mConnectState = false;
        updateShowState();
    }

    private void BluetoothServiceinit() {
        //清除旧连接服务
        closebluetooth();
        Intent gattServiceIntent = new Intent(this, BluetoothLeService.class);
        bindService(gattServiceIntent, mServiceConnection, BIND_AUTO_CREATE);

        setContentView(R.layout.activity_main);
        updateDateAvailable(true);
    }

    private final ServiceConnection mServiceConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            mBluetoothLeService = ((BluetoothLeService.LocalBinder) service).getService();
            if (!mBluetoothLeService.initialize()) {   //初始函数会返回一个值，判断有没有开蓝牙
                Log.e("TAG", "没有能够得到蓝牙的管理者！");
            }
            if (mBluetoothLeService != null && !mConnectState) {
                Log.e("TAG", "连接点击了...");
                Toast.makeText(getApplicationContext(), "Connecting...", Toast.LENGTH_SHORT).show();
                //自动连接几秒后断开自动连接！
                mHandler.sendEmptyMessageDelayed(CLOSEPROGRESS, 3000);  //3秒钟后通知
                mBluetoothLeService.connect(mDeviceAddress);    //连接设备
            }
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            mBluetoothLeService = null;
        }
    };
    private void updateShowState(){
        TextView text=findViewById(R.id.text_state);
        TextView button=findViewById(R.id.button_state);
        if(mConnectState){
            text.setText(getResources().getString(R.string.status_connected));
            button.setText(getResources().getString(R.string.disconnect));
        }else{
            text.setText(getResources().getString(R.string.status_disconnected));
            button.setText(getResources().getString(R.string.connect));
        }
    };


    private OSS oss;
    List<String> paths = new ArrayList<>(); // 本地需要上传图片的集合路径

    // 这个是外网域名的后半部分(外网域名 = bucket.endpoint)，根据你申请的填一般是"http://oss-cn-hangzhou.aliyuncs.com"
    private static final String endpoint = "http://oss-cn-hangzhou.aliyuncs.com";
    private static final String accessKeyId = "LTAI5tHBE9rx3TxxEZ5i1GHP";  // 你申请的accessKeyId
    private static final String accessKeySecret = "lRC8xN7du42zbSzo7fk9xj6CdIePxJ"; // accessKeySecret
    //private static final String uploadFilePath = "/storage/emulated/0/MultiParameterRecord/2022-6-12.csv"; // 这个路径是你要上传的文件的路径（本地）
    private static final String uploadFilePath = "/storage/emulated/0/MultiParameterRecord/test1.csv"; // 这个路径是你要上传的文件的路径（本地）
    //存储的文件名

    private static final String testBucket = "wangh-001";  // 这个就是你申请的bucket名称
    private String uploadObject = getPhotoFileName();  // 这个是你要上传到OSS的文件路径，加入想上传到文件夹则前面加上****/****形式的路径即可
    /**初始化阿里云*/


    private void initOSS() {
        OSSCredentialProvider credentialProvider = new OSSPlainTextAKSKCredentialProvider(accessKeyId, accessKeySecret);

        ClientConfiguration conf = new ClientConfiguration();
        conf.setConnectionTimeout(15 * 1000); // 连接超时，默认15秒
        conf.setSocketTimeout(15 * 1000); // socket超时，默认15秒
        conf.setMaxConcurrentRequest(5); // 最大并发请求书，默认5个
        conf.setMaxErrorRetry(2); // 失败后最大重试次数，默认2次
        OSSLog.enableLog();
        oss = new OSSClient(getApplicationContext(), endpoint, credentialProvider, conf);
    }



    /**
     *
     * @return 数据上传至阿里云的位置和名字
     * yyyyMMddHHmmssSSS为命名规则
     */
    public static String getPhotoFileName() {
        Date date = new Date(System.currentTimeMillis());
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMddHHmmssSSS", Locale.getDefault());
        //return "CSV" + "/" + dateFormat.format(date) + ".csv";
        return "CSV" + "/" + "test1"+ ".csv";
    }



    //存传输过来的数据
    private int CsvData_Count=0;
    private int[] CsvData_Storage = new int[100];
    private String CsvData_SaveDir;

    private final BroadcastReceiver mGattUpdateReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();//得到广播接收器
            switch (action) {
                case BluetoothLeService.ACTION_GATT_CONNECTED://连接到蓝牙设备发送的广播！
                    Log.e("TAG", "收到已经连接的广播");
                    mConnectState = true;
                    updateShowState();
                    Toast.makeText(getApplicationContext(), "Connect Succes!Address:"+mDeviceAddress, Toast.LENGTH_SHORT).show();
                    break;
                case BluetoothLeService.ACTION_GATT_DISCONNECTED:
                    Log.e("TAG", "收到蓝牙断开连接的广播！");
                    //界面改变和断开蓝牙显示
                    Toast.makeText(getApplicationContext(), "Unconnected!", Toast.LENGTH_SHORT).show();
                    mConnectState = false;
                    updateShowState();
                    break;
                case BluetoothLeService.ACTION_GATT_SERVICES_DISCOVERED:
                    Log.e("TAG", "收到蓝牙服务被发现的广播！");
                    break;
                case BluetoothLeService.ACTION_DATA_AVAILABLE://处理接受的数据在这里----------------------------------------------------------------------------------------------------------------
                    //Log.e("TAG", "收到蓝牙广播----收到数据的广播！");
                    //将读取到的数据进行处理操作
                    String Receive_String = intent.getStringExtra(BluetoothLeService.EXTRA_DATA);
                    char[] bs = Receive_String.toCharArray();   //将输入的二进制字符串转换为字符数组，输入为0x11，输出为'1','1'
                    Log.e("bs-length", "bs的长度"+bs.length);
                    try{
                        int Gas_Data=(Character.getNumericValue(bs[0]) * 16 * 16 * 16 + Character.getNumericValue(bs[1]) * 16 * 16
                                + Character.getNumericValue(bs[2]) * 16 + Character.getNumericValue(bs[3]));
                        mData.add(Gas_Data);
                        // 用数组存储数据，同时用一个变量判断数据是否存满
                        if(CsvData_Count < 10)
                        {
                            CsvData_Storage[CsvData_Count] = Gas_Data;
                            CsvData_Count = CsvData_Count + 1;
                        }else {
                            //数据满，存储到csv文件夹并上传至云端 （先看下延迟如何，如果会丢数据就开个线程完成）
                            //数据存储（不能采用填充模式，需要将之前的数据清空）
                            boolean isSucess=true;
                            CsvData_SaveDir = Environment.getExternalStorageDirectory().getAbsolutePath()+"/MultiParameterRecord/"+"test1.csv";
                            if(!(new File(CsvData_SaveDir)).exists()) {
                                try {
                                    isSucess = file_IO.write(CsvData_SaveDir, "Nitricoxide,Sodium,PH,Uric acid,Temperature,Calcium\r\n");
                                } catch (IOException e) {
                                    e.printStackTrace();
                                }
                            }

                            for(int i = 0 ; i < 10 ; i++)
                            {
                                try{
                                    file_IO.append(CsvData_SaveDir,Gas_Data+"\r\n");
                                }catch (IOException e){
                                    e.printStackTrace();
                                }
                            }
                            //数据上传云端
                            new Thread(new Runnable() {
                                @Override
                                public void run() {
                                    Log.e("asyncPutObject", "asyncPutObjectFromLocalFile");    //这个程序运行了，但是没有改进
                                    asyncPutObjectFromLocalFile(uploadObject,uploadFilePath);
                                }
                            }).start();
                            //重新采集数据
                            CsvData_Count = 0;
                            CsvData_Storage[CsvData_Count] = Gas_Data;
                            CsvData_Count = CsvData_Count + 1;
                        }
                    }catch (IndexOutOfBoundsException | NumberFormatException e){
                        e.printStackTrace();
                    }
                    break;
            }
        }
    };


    /**
     * 从本地文件上传，使用非阻塞的异步接口
     * @param uploadObject 这个是你要上传到OSS的文件路径，加入想上传到文件夹则前面加上xxx/xxx形式的路径即可
     * @param locationPath  这个路径是你要上传的文件的路径（本地）
     */
    public void asyncPutObjectFromLocalFile(final String uploadObject, String locationPath) {
        // 指定数据类型，没有指定会自动根据后缀名判断
//        ObjectMetadata objectMeta = new ObjectMetadata();
//        objectMeta.setContentType("image/jpeg");

        /**
         * 构造上传请求
         * oss 配置
         * testBucket 申请的Bucket名称
         * uploadObject  这个是你要上传到OSS的文件路径（一般是  "img" + "/" + "当前时间" + ".jpg";）
         * path  这个路径是你要上传的文件的路径（本地）
         */
        PutObjectRequest put = new PutObjectRequest(testBucket, uploadObject, locationPath);
//        put.setMetadata(objectMeta);

        // 异步上传时可以设置进度回调
        put.setProgressCallback(new OSSProgressCallback<PutObjectRequest>() {
            @Override
            public void onProgress(PutObjectRequest request, long currentSize, long totalSize) {
                // 在这里可以实现进度条展现功能
                Log.d("PutObject", "currentSize: " + currentSize + " totalSize: " + totalSize);
            }
        });

        oss.asyncPutObject(put, new OSSCompletedCallback<PutObjectRequest, PutObjectResult>() {
            @Override
            public void onSuccess(PutObjectRequest request, PutObjectResult result) {
                Log.d("PutObject", "UploadSuccess");
                Log.e("PutObject", "上传CSV文件成功");

                Log.d("ETag", result.getETag());
                Log.d("RequestId", result.getRequestId());
            }

            @Override
            public void onFailure(PutObjectRequest request, ClientException clientExcepion, ServiceException serviceException) {
                // 请求异常
                if (clientExcepion != null) {
                    // 本地异常如网络异常等
                    clientExcepion.printStackTrace();
                }
                if (serviceException != null) {
                    // 服务异常
                    Log.e("ErrorCode", serviceException.getErrorCode());
                    Log.e("RequestId", serviceException.getRequestId());
                    Log.e("HostId", serviceException.getHostId());
                    Log.e("RawMessage", serviceException.getRawMessage());
                }
//                ToastUtils.showShort(mContext, "图片上传失败，请重新上传");
            }
        });
    }



}