//**********************************************************************
//name:         GUA_LCD.h
//introduce:    ��ϵ�LCD������ͷ�ļ�
//author:       ����Ĵ����
//email:        897503845@qq.com
//QQ group:     ���BLE֮CC2640R2F(557278427)
//shop:
//https://shop217632629.taobao.com/?spm=2013.1.1000126.d21.hd2o8i
//changetime:   2017.10.28
//**********************************************************************
#ifndef _GUA_LCD_H_
#define _GUA_LCD_H_

/*********************�궨��************************/
//���ͺ�
#ifndef GUA_C
typedef char GUA_C;
#endif

#ifndef GUA_U8
typedef unsigned char GUA_U8;
#endif

#ifndef GUA_8
typedef signed char GUA_8;
#endif

#ifndef GUA_U16
typedef unsigned short GUA_U16;
#endif

#ifndef GUA_16
typedef signed short GUA_16;
#endif

#ifndef GUA_U32
typedef unsigned long GUA_U32;
#endif

#ifndef GUA_32
typedef signed long GUA_32;
#endif

#ifndef GUA_U64
typedef unsigned long long GUA_U64;
#endif

#ifndef GUA_64
typedef signed long long GUA_64;
#endif

//LCD�Ŀ�д��
typedef enum
{
    GUA_LCD_LINE0 = 0,
    GUA_LCD_LINE1,
    GUA_LCD_LINE2,
    GUA_LCD_LINE3,
    GUA_LCD_LINE4,
    GUA_LCD_LINE5,
    GUA_LCD_LINE6,
    GUA_LCD_LINE7,
    GUA_LCD_LINE_COUNT
}GUA_LCD_LINE;

/*********************��������************************/
extern void GUA_LCD_Init(void);
extern void GUA_LCD_WriteValue(GUA_U32 nGUA_Value, GUA_U8 nGUA_Format, GUA_U8 nGUA_Line);
extern void GUA_LCD_WriteString(GUA_C *pGUA_Str, GUA_U8 nGUA_Line);
extern void GUA_LCD_WriteStringValue(GUA_C *pGUA_Str, GUA_U32 nGUA_Value, GUA_U8 nGUA_Format, GUA_U8 nGUA_Line);
extern void GUA_LCD_ClearLine(GUA_U8 nGUA_Line);

#endif
