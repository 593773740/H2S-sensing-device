//**********************************************************************
//name:         GUA_Led.h        
//introduce:    ����Զ����LED����ͷ�ļ�
//author:       ����Ĵ����      
//email:        897503845@qq.com   
//QQ group:     ���BLE֮CC2640R2F(557278427)
//shop:
//https://shop217632629.taobao.com/?spm=2013.1.1000126.d21.hd2o8i
//changetime:   2017.09.20
//**********************************************************************
#ifndef _GUA_LED_H_
#define _GUA_LED_H_

/*********************�궨��************************/ 
//���ͺ�
#ifndef GUA_U8
typedef unsigned char GUA_U8;
#endif

//LEDS
#define GUA_LED_NO_1            0x01
#define GUA_LED_NO_2            0x02
#define GUA_LED_NO_3            0x04
#define GUA_LED_NO_4            0x08
#define GUA_LED_NO_ALL          (GUA_LED_NO_1 | GUA_LED_NO_2 | GUA_LED_NO_3 | GUA_LED_NO_4)

//Modes
#define GUA_LED_MODE_OFF        0x00
#define GUA_LED_MODE_ON         0x01
#define GUA_LED_MODE_FLASH      0x02
#define GUA_LED_MODE_TOGGLE     0x04

/*********************��������************************/ 
extern void GUA_Led_Set(GUA_U8 nGUA_Led_No, GUA_U8 nGUA_Mode);

#endif
