//**********************************************************************
//name:         GUA_Beep.c
//introduce:    ����Զ���ķ���������
//author:       ����Ĵ����      
//email:        897503845@qq.com   
//QQ group:     ���BLE֮CC2640R2F(557278427)
//shop:
//https://shop217632629.taobao.com/?spm=2013.1.1000126.d21.hd2o8i
//changetime:   2017.10.17
//**********************************************************************
#include <string.h>
#include <stdio.h>

#include <ti/sysbios/knl/Task.h>
#include <ti/sysbios/knl/Clock.h>
#include <ti/sysbios/knl/Semaphore.h>
#include <ti/sysbios/knl/Queue.h>

#include <ti/drivers/PIN.h>
#include <ti/drivers/pin/PINCC26XX.h>

#include "GUA_Beep.h"

/*********************�궨��************************/   
//IO��Ӧ��ϵ
#define GUA_ID_BEEP     PIN_ID(13)

/*********************�ڲ�����************************/  
static PIN_State  sGUA_BeepPins;
static PIN_Handle sGUA_HBeepPins = NULL;

//IO����
PIN_Config bGUA_BeepPinsCfg[] =
{
    GUA_ID_BEEP | PIN_GPIO_OUTPUT_EN | PIN_GPIO_LOW | PIN_PUSHPULL | PIN_DRVSTR_MAX,
    PIN_TERMINATE
};

//**********************************************************************
//name:         GUA_Beep_Set
//introduce:    ��Ϸ���������
//parameter:    nGUA_Mode��GUA_BEEP_MODE_OFF��GUA_BEEP_MODE_ON��
//return:       none
//author:       ����Ĵ����
//email:        897503845@qq.com
//QQ group:     ���BLE֮CC2640R2F(557278427)
//shop:
//https://shop217632629.taobao.com/?spm=2013.1.1000126.d21.hd2o8i
//changetime:   2017.10.17
//**********************************************************************
void GUA_Beep_Set(GUA_U8 nGUA_Mode)
{
    //��һ��ʹ��ʱע��IO
    if(NULL == sGUA_HBeepPins)
    {
        sGUA_HBeepPins = PIN_open(&sGUA_BeepPins, bGUA_BeepPinsCfg);
    }

    //ִ��ģʽ
    switch(nGUA_Mode)
    {
        //��������ģʽ
        case GUA_BEEP_MODE_OFF:
        {
            PIN_setOutputValue(sGUA_HBeepPins, GUA_ID_BEEP, 0);
            break;
        }

        //����������ģʽ
        case GUA_BEEP_MODE_ON:
        {
            PIN_setOutputValue(sGUA_HBeepPins, GUA_ID_BEEP, 1);
            break;
        }

        //����
        default:break;
    }
}
