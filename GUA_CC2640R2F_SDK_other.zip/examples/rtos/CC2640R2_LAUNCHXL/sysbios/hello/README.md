## Example Summary

This application serves as a basic sanity check program for SYS/BIOS.
It demonstrates how to print to stdout.

## Example Usage

* Run the application, the string `hello world` will be printed to the console.

## Application Design Details
* N/A

## References

* For more help, search the SYS/BIOS User Guide.