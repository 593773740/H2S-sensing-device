## Project Summary

This project contains settings to enable the standard debug features in
TI-RTOS.

## Project Usage

This project is intended to be used by applications that need a debug rich
TI-RTOS configuration. Multiple applications can use this project.

Please refer to the TI-RTOS Kernel section in the SimpleLink MCU SDK User's
Guide for the details on how applications use this project.
