/*
 *  Do not modify this file; it is automatically 
 *  generated and any modifications will be overwritten.
 *
 * @(#) xdc-D13
 */

#ifndef ti_catalog_arm_cortexm4_tiva_ce__
#define ti_catalog_arm_cortexm4_tiva_ce__


/*
 * ======== module ti.catalog.arm.cortexm4.tiva.ce.Boot ========
 */



#endif /* ti_catalog_arm_cortexm4_tiva_ce__ */ 
