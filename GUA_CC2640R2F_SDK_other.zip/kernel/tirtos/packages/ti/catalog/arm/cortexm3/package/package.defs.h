/*
 *  Do not modify this file; it is automatically 
 *  generated and any modifications will be overwritten.
 *
 * @(#) xdc-D13
 */

#ifndef ti_catalog_arm_cortexm3__
#define ti_catalog_arm_cortexm3__



#endif /* ti_catalog_arm_cortexm3__ */ 
