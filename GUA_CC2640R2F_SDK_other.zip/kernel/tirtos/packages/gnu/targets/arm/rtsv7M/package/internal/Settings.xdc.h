/*
 *  Do not modify this file; it is automatically 
 *  generated and any modifications will be overwritten.
 *
 * @(#) xdc-D13
 */

#ifndef gnu_targets_arm_rtsv7M_Settings__INTERNAL__
#define gnu_targets_arm_rtsv7M_Settings__INTERNAL__

#ifndef gnu_targets_arm_rtsv7M_Settings__internalaccess
#define gnu_targets_arm_rtsv7M_Settings__internalaccess
#endif

#include <gnu/targets/arm/rtsv7M/Settings.h>

#undef xdc_FILE__
#ifndef xdc_FILE
#define xdc_FILE__ NULL
#else
#define xdc_FILE__ xdc_FILE
#endif

/* Module_startup */
#undef gnu_targets_arm_rtsv7M_Settings_Module_startup
#define gnu_targets_arm_rtsv7M_Settings_Module_startup gnu_targets_arm_rtsv7M_Settings_Module_startup__E

/* Instance_init */
#undef gnu_targets_arm_rtsv7M_Settings_Instance_init
#define gnu_targets_arm_rtsv7M_Settings_Instance_init gnu_targets_arm_rtsv7M_Settings_Instance_init__E

/* Instance_finalize */
#undef gnu_targets_arm_rtsv7M_Settings_Instance_finalize
#define gnu_targets_arm_rtsv7M_Settings_Instance_finalize gnu_targets_arm_rtsv7M_Settings_Instance_finalize__E

/* per-module runtime symbols */
#undef Module__MID
#ifdef gnu_targets_arm_rtsv7M_Settings_Module__id__CR
#define Module__MID (*((CT__gnu_targets_arm_rtsv7M_Settings_Module__id *)(xdcRomConstPtr + gnu_targets_arm_rtsv7M_Settings_Module__id__C_offset)))
#else
#define Module__MID gnu_targets_arm_rtsv7M_Settings_Module__id__C
#endif

#undef Module__DGSINCL
#ifdef gnu_targets_arm_rtsv7M_Settings_Module__diagsIncluded__CR
#define Module__DGSINCL (*((CT__gnu_targets_arm_rtsv7M_Settings_Module__diagsIncluded *)(xdcRomConstPtr + gnu_targets_arm_rtsv7M_Settings_Module__diagsIncluded__C_offset)))
#else
#define Module__DGSINCL gnu_targets_arm_rtsv7M_Settings_Module__diagsIncluded__C
#endif

#undef Module__DGSENAB
#ifdef gnu_targets_arm_rtsv7M_Settings_Module__diagsEnabled__CR
#define Module__DGSENAB (*((CT__gnu_targets_arm_rtsv7M_Settings_Module__diagsEnabled *)(xdcRomConstPtr + gnu_targets_arm_rtsv7M_Settings_Module__diagsEnabled__C_offset)))
#else
#define Module__DGSENAB gnu_targets_arm_rtsv7M_Settings_Module__diagsEnabled__C
#endif

#undef Module__DGSMASK
#ifdef gnu_targets_arm_rtsv7M_Settings_Module__diagsMask__CR
#define Module__DGSMASK (*((CT__gnu_targets_arm_rtsv7M_Settings_Module__diagsMask *)(xdcRomConstPtr + gnu_targets_arm_rtsv7M_Settings_Module__diagsMask__C_offset)))
#else
#define Module__DGSMASK gnu_targets_arm_rtsv7M_Settings_Module__diagsMask__C
#endif

#undef Module__LOGDEF
#ifdef gnu_targets_arm_rtsv7M_Settings_Module__loggerDefined__CR
#define Module__LOGDEF (*((CT__gnu_targets_arm_rtsv7M_Settings_Module__loggerDefined *)(xdcRomConstPtr + gnu_targets_arm_rtsv7M_Settings_Module__loggerDefined__C_offset)))
#else
#define Module__LOGDEF gnu_targets_arm_rtsv7M_Settings_Module__loggerDefined__C
#endif

#undef Module__LOGOBJ
#ifdef gnu_targets_arm_rtsv7M_Settings_Module__loggerObj__CR
#define Module__LOGOBJ gnu_targets_arm_rtsv7M_Settings_Module__loggerObj__R
#define Module__LOGOBJ (*((CT__gnu_targets_arm_rtsv7M_Settings_Module__loggerObj *)(xdcRomConstPtr + gnu_targets_arm_rtsv7M_Settings_Module__loggerObj__C_offset)))
#else
#define Module__LOGOBJ gnu_targets_arm_rtsv7M_Settings_Module__loggerObj__C
#endif

#undef Module__LOGFXN0
#ifdef gnu_targets_arm_rtsv7M_Settings_Module__loggerFxn0__CR
#define Module__LOGFXN0 (*((CT__gnu_targets_arm_rtsv7M_Settings_Module__loggerFxn0 *)(xdcRomConstPtr + gnu_targets_arm_rtsv7M_Settings_Module__loggerFxn0__C_offset)))
#else
#define Module__LOGFXN0 gnu_targets_arm_rtsv7M_Settings_Module__loggerFxn0__C
#endif

#undef Module__LOGFXN1
#ifdef gnu_targets_arm_rtsv7M_Settings_Module__loggerFxn1__CR
#define Module__LOGFXN1 (*((CT__gnu_targets_arm_rtsv7M_Settings_Module__loggerFxn1 *)(xdcRomConstPtr + gnu_targets_arm_rtsv7M_Settings_Module__loggerFxn1__C_offset)))
#else
#define Module__LOGFXN1 gnu_targets_arm_rtsv7M_Settings_Module__loggerFxn1__C
#endif

#undef Module__LOGFXN2
#ifdef gnu_targets_arm_rtsv7M_Settings_Module__loggerFxn2__CR
#define Module__LOGFXN2 (*((CT__gnu_targets_arm_rtsv7M_Settings_Module__loggerFxn2 *)(xdcRomConstPtr + gnu_targets_arm_rtsv7M_Settings_Module__loggerFxn2__C_offset)))
#else
#define Module__LOGFXN2 gnu_targets_arm_rtsv7M_Settings_Module__loggerFxn2__C
#endif

#undef Module__LOGFXN4
#ifdef gnu_targets_arm_rtsv7M_Settings_Module__loggerFxn4__CR
#define Module__LOGFXN4 (*((CT__gnu_targets_arm_rtsv7M_Settings_Module__loggerFxn4 *)(xdcRomConstPtr + gnu_targets_arm_rtsv7M_Settings_Module__loggerFxn4__C_offset)))
#else
#define Module__LOGFXN4 gnu_targets_arm_rtsv7M_Settings_Module__loggerFxn4__C
#endif

#undef Module__LOGFXN8
#ifdef gnu_targets_arm_rtsv7M_Settings_Module__loggerFxn8__CR
#define Module__LOGFXN8 (*((CT__gnu_targets_arm_rtsv7M_Settings_Module__loggerFxn8 *)(xdcRomConstPtr + gnu_targets_arm_rtsv7M_Settings_Module__loggerFxn8__C_offset)))
#else
#define Module__LOGFXN8 gnu_targets_arm_rtsv7M_Settings_Module__loggerFxn8__C
#endif

#undef Module__G_OBJ
#ifdef gnu_targets_arm_rtsv7M_Settings_Module__gateObj__CR
#define Module__G_OBJ (*((CT__gnu_targets_arm_rtsv7M_Settings_Module__gateObj *)(xdcRomConstPtr + gnu_targets_arm_rtsv7M_Settings_Module__gateObj__C_offset)))
#else
#define Module__G_OBJ gnu_targets_arm_rtsv7M_Settings_Module__gateObj__C
#endif

#undef Module__G_PRMS
#ifdef gnu_targets_arm_rtsv7M_Settings_Module__gatePrms__CR
#define Module__G_PRMS (*((CT__gnu_targets_arm_rtsv7M_Settings_Module__gatePrms *)(xdcRomConstPtr + gnu_targets_arm_rtsv7M_Settings_Module__gatePrms__C_offset)))
#else
#define Module__G_PRMS gnu_targets_arm_rtsv7M_Settings_Module__gatePrms__C
#endif

#undef Module__GP_create
#define Module__GP_create gnu_targets_arm_rtsv7M_Settings_Module_GateProxy_create
#undef Module__GP_delete
#define Module__GP_delete gnu_targets_arm_rtsv7M_Settings_Module_GateProxy_delete
#undef Module__GP_enter
#define Module__GP_enter gnu_targets_arm_rtsv7M_Settings_Module_GateProxy_enter
#undef Module__GP_leave
#define Module__GP_leave gnu_targets_arm_rtsv7M_Settings_Module_GateProxy_leave
#undef Module__GP_query
#define Module__GP_query gnu_targets_arm_rtsv7M_Settings_Module_GateProxy_query


#endif /* gnu_targets_arm_rtsv7M_Settings__INTERNAL____ */
