/*
 *  Do not modify this file; it is automatically 
 *  generated and any modifications will be overwritten.
 *
 * @(#) xdc-D13
 */

#ifndef gnu_targets__
#define gnu_targets__



#endif /* gnu_targets__ */ 
