/*
 *  Do not modify this file; it is automatically 
 *  generated and any modifications will be overwritten.
 *
 * @(#) xdc-D13
 */

#ifndef iar_targets_arm_rts_Settings__INTERNAL__
#define iar_targets_arm_rts_Settings__INTERNAL__

#ifndef iar_targets_arm_rts_Settings__internalaccess
#define iar_targets_arm_rts_Settings__internalaccess
#endif

#include <iar/targets/arm/rts/Settings.h>

#undef xdc_FILE__
#ifndef xdc_FILE
#define xdc_FILE__ NULL
#else
#define xdc_FILE__ xdc_FILE
#endif

/* Module_startup */
#undef iar_targets_arm_rts_Settings_Module_startup
#define iar_targets_arm_rts_Settings_Module_startup iar_targets_arm_rts_Settings_Module_startup__E

/* Instance_init */
#undef iar_targets_arm_rts_Settings_Instance_init
#define iar_targets_arm_rts_Settings_Instance_init iar_targets_arm_rts_Settings_Instance_init__E

/* Instance_finalize */
#undef iar_targets_arm_rts_Settings_Instance_finalize
#define iar_targets_arm_rts_Settings_Instance_finalize iar_targets_arm_rts_Settings_Instance_finalize__E

/* per-module runtime symbols */
#undef Module__MID
#ifdef iar_targets_arm_rts_Settings_Module__id__CR
#define Module__MID (*((CT__iar_targets_arm_rts_Settings_Module__id *)(xdcRomConstPtr + iar_targets_arm_rts_Settings_Module__id__C_offset)))
#else
#define Module__MID iar_targets_arm_rts_Settings_Module__id__C
#endif

#undef Module__DGSINCL
#ifdef iar_targets_arm_rts_Settings_Module__diagsIncluded__CR
#define Module__DGSINCL (*((CT__iar_targets_arm_rts_Settings_Module__diagsIncluded *)(xdcRomConstPtr + iar_targets_arm_rts_Settings_Module__diagsIncluded__C_offset)))
#else
#define Module__DGSINCL iar_targets_arm_rts_Settings_Module__diagsIncluded__C
#endif

#undef Module__DGSENAB
#ifdef iar_targets_arm_rts_Settings_Module__diagsEnabled__CR
#define Module__DGSENAB (*((CT__iar_targets_arm_rts_Settings_Module__diagsEnabled *)(xdcRomConstPtr + iar_targets_arm_rts_Settings_Module__diagsEnabled__C_offset)))
#else
#define Module__DGSENAB iar_targets_arm_rts_Settings_Module__diagsEnabled__C
#endif

#undef Module__DGSMASK
#ifdef iar_targets_arm_rts_Settings_Module__diagsMask__CR
#define Module__DGSMASK (*((CT__iar_targets_arm_rts_Settings_Module__diagsMask *)(xdcRomConstPtr + iar_targets_arm_rts_Settings_Module__diagsMask__C_offset)))
#else
#define Module__DGSMASK iar_targets_arm_rts_Settings_Module__diagsMask__C
#endif

#undef Module__LOGDEF
#ifdef iar_targets_arm_rts_Settings_Module__loggerDefined__CR
#define Module__LOGDEF (*((CT__iar_targets_arm_rts_Settings_Module__loggerDefined *)(xdcRomConstPtr + iar_targets_arm_rts_Settings_Module__loggerDefined__C_offset)))
#else
#define Module__LOGDEF iar_targets_arm_rts_Settings_Module__loggerDefined__C
#endif

#undef Module__LOGOBJ
#ifdef iar_targets_arm_rts_Settings_Module__loggerObj__CR
#define Module__LOGOBJ iar_targets_arm_rts_Settings_Module__loggerObj__R
#define Module__LOGOBJ (*((CT__iar_targets_arm_rts_Settings_Module__loggerObj *)(xdcRomConstPtr + iar_targets_arm_rts_Settings_Module__loggerObj__C_offset)))
#else
#define Module__LOGOBJ iar_targets_arm_rts_Settings_Module__loggerObj__C
#endif

#undef Module__LOGFXN0
#ifdef iar_targets_arm_rts_Settings_Module__loggerFxn0__CR
#define Module__LOGFXN0 (*((CT__iar_targets_arm_rts_Settings_Module__loggerFxn0 *)(xdcRomConstPtr + iar_targets_arm_rts_Settings_Module__loggerFxn0__C_offset)))
#else
#define Module__LOGFXN0 iar_targets_arm_rts_Settings_Module__loggerFxn0__C
#endif

#undef Module__LOGFXN1
#ifdef iar_targets_arm_rts_Settings_Module__loggerFxn1__CR
#define Module__LOGFXN1 (*((CT__iar_targets_arm_rts_Settings_Module__loggerFxn1 *)(xdcRomConstPtr + iar_targets_arm_rts_Settings_Module__loggerFxn1__C_offset)))
#else
#define Module__LOGFXN1 iar_targets_arm_rts_Settings_Module__loggerFxn1__C
#endif

#undef Module__LOGFXN2
#ifdef iar_targets_arm_rts_Settings_Module__loggerFxn2__CR
#define Module__LOGFXN2 (*((CT__iar_targets_arm_rts_Settings_Module__loggerFxn2 *)(xdcRomConstPtr + iar_targets_arm_rts_Settings_Module__loggerFxn2__C_offset)))
#else
#define Module__LOGFXN2 iar_targets_arm_rts_Settings_Module__loggerFxn2__C
#endif

#undef Module__LOGFXN4
#ifdef iar_targets_arm_rts_Settings_Module__loggerFxn4__CR
#define Module__LOGFXN4 (*((CT__iar_targets_arm_rts_Settings_Module__loggerFxn4 *)(xdcRomConstPtr + iar_targets_arm_rts_Settings_Module__loggerFxn4__C_offset)))
#else
#define Module__LOGFXN4 iar_targets_arm_rts_Settings_Module__loggerFxn4__C
#endif

#undef Module__LOGFXN8
#ifdef iar_targets_arm_rts_Settings_Module__loggerFxn8__CR
#define Module__LOGFXN8 (*((CT__iar_targets_arm_rts_Settings_Module__loggerFxn8 *)(xdcRomConstPtr + iar_targets_arm_rts_Settings_Module__loggerFxn8__C_offset)))
#else
#define Module__LOGFXN8 iar_targets_arm_rts_Settings_Module__loggerFxn8__C
#endif

#undef Module__G_OBJ
#ifdef iar_targets_arm_rts_Settings_Module__gateObj__CR
#define Module__G_OBJ (*((CT__iar_targets_arm_rts_Settings_Module__gateObj *)(xdcRomConstPtr + iar_targets_arm_rts_Settings_Module__gateObj__C_offset)))
#else
#define Module__G_OBJ iar_targets_arm_rts_Settings_Module__gateObj__C
#endif

#undef Module__G_PRMS
#ifdef iar_targets_arm_rts_Settings_Module__gatePrms__CR
#define Module__G_PRMS (*((CT__iar_targets_arm_rts_Settings_Module__gatePrms *)(xdcRomConstPtr + iar_targets_arm_rts_Settings_Module__gatePrms__C_offset)))
#else
#define Module__G_PRMS iar_targets_arm_rts_Settings_Module__gatePrms__C
#endif

#undef Module__GP_create
#define Module__GP_create iar_targets_arm_rts_Settings_Module_GateProxy_create
#undef Module__GP_delete
#define Module__GP_delete iar_targets_arm_rts_Settings_Module_GateProxy_delete
#undef Module__GP_enter
#define Module__GP_enter iar_targets_arm_rts_Settings_Module_GateProxy_enter
#undef Module__GP_leave
#define Module__GP_leave iar_targets_arm_rts_Settings_Module_GateProxy_leave
#undef Module__GP_query
#define Module__GP_query iar_targets_arm_rts_Settings_Module_GateProxy_query


#endif /* iar_targets_arm_rts_Settings__INTERNAL____ */
