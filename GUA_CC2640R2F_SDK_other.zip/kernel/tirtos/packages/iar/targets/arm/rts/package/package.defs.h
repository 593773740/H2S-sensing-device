/*
 *  Do not modify this file; it is automatically 
 *  generated and any modifications will be overwritten.
 *
 * @(#) xdc-D13
 */

#ifndef iar_targets_arm_rts__
#define iar_targets_arm_rts__


/*
 * ======== module iar.targets.arm.rts.Settings ========
 */



#endif /* iar_targets_arm_rts__ */ 
