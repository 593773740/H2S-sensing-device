/*
 *  Do not modify this file; it is automatically 
 *  generated and any modifications will be overwritten.
 *
 * @(#) xdc-A65
 */

#ifndef iar_tools_configuro__
#define iar_tools_configuro__



#endif /* iar_tools_configuro__ */ 
